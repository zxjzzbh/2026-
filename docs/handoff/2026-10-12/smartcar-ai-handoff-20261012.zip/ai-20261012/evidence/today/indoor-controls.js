
(()=>{
const key=__DRIVE_KEY__, pageSession=__DRIVE_SESSION__, el=id=>document.getElementById(id);
const client=Array.from(crypto.getRandomValues(new Uint8Array(16)),x=>x.toString(16).padStart(2,'0')).join('');
let held=new Map(), sequence=0, busy=false, heartbeatDue=false, allowed=false, turnAvailable=true, motorAvailable=true, reverseAvailable=true, urgentGeneration=0, needsRelease=true, stopPending=false;
let motionInFlight=0, commandReplySequence=-1;
let stale=false, enabling=false, lastStatus=null, requestError='', localHint='', latency=null, speedWanted=null, speedBusy=false;
let gamepadControl=null,pwmControl=null;
let coneActive=false,coneDirty=false,coneBusy=false,coneImageBusy=false,coneImageURL=null,coneError='';
const coneInputs=['cone-h-low','cone-h-high','cone-s-low','cone-v-low','cone-confirm','cone-red-percent'];
let coneDriveActive=false,coneDriveOwned=false,coneToken=null,coneSequence=0,conePulseBusy=false,coneRunQueue=Promise.resolve();
let coneLastSnapshot=-Infinity;
let coneShortActive=false,coneShortOwned=false,coneShortToken=null,coneShortRound=0,coneShortSequence=0,coneShortPulseBusy=false,coneShortStartBusy=false,coneShortQueue=Promise.resolve();

let trafficActive=false,trafficOwned=false,trafficToken=null,trafficSequence=0,trafficPulseBusy=0,trafficSettingsRevision=null,trafficSaveBusy=false,trafficDirty=false,trafficStartBusy=false,trafficStartError="",trafficLastStatusAt=-Infinity;
let brakeActive=false,brakeOwned=false,brakeToken=null,brakeSequence=0,brakePulseBusy=0,brakeSettingsRevision=null,brakeSettingsDirty=false,brakeSaveBusy=false;
let reverseTrimBusy=false,reverseTrimDirty=false,reverseTrimWanted=null;
const directionNames={forward:'前进',reverse:'倒车',left:'左转',right:'右转'};
const keys={ArrowUp:'forward',w:'forward',W:'forward',ArrowDown:'reverse',s:'reverse',S:'reverse',ArrowLeft:'left',a:'left',A:'left',ArrowRight:'right',d:'right',D:'right'};
const keyDirection=e=>keys[e.key]||({KeyW:'forward',KeyS:'reverse',KeyA:'left',KeyD:'right'})[e.code];
const keySource=e=>'key:'+(e.code||e.key.toLowerCase());
function feedback(message,tone='idle'){
 const colors={idle:'#c5b6d1',ready:'#a855f7',sending:'#d6a44b',error:'#d45570'};
 el('drive-feedback').textContent=message;el('drive-feedback').style.borderColor=colors[tone];
 el('drive-feedback').setAttribute?.('data-tone',tone);
}
function paintConnection(state){
 el('drive-link').setAttribute?.('data-link-state',state);
 el('drive-link').style.color='';
}
function expiredPage(){
 pwmControl?.cancel();
 stale=true;held.clear();allowed=false;urgentGeneration++;
 paintConnection('stale');
 el('drive-mode').textContent='控制页面已过期，请刷新后核对当前模式。';
 el('drive-time').textContent='本页已禁止发送方向请求。';
 el('drive-refresh').hidden=false;el('drive-enable').disabled=true;
 document.querySelectorAll('[data-drive]').forEach(b=>b.disabled=true);
 feedback('控制服务已更新：请刷新页面，再重新启用短测。','error');
}
async function send(action,body={},keepalive=false){
 const started=performance.now(),controller=new AbortController(), timer=setTimeout(()=>controller.abort(),2000);
 try{
 const response=await fetch('/api/drive/'+action,{method:'POST',headers:{'Content-Type':'application/json','X-Drive-Key':key},
 body:JSON.stringify({client,trial_token:lastStatus?.trial_token,setup_token:lastStatus?.setup_token,...body}),cache:'no-store',keepalive,signal:controller.signal});
 const result=await response.json();latency=Math.round(performance.now()-started);if(!response.ok){if(result.code==='control_page_rejected')expiredPage();throw new Error(result.error||'控制请求失败');}return result;
 }catch(e){if(e.name==='AbortError')throw new Error('2秒内未收到控制确认');throw e;}
 finally{clearTimeout(timer);}
}
function renderLegacy(s){
 const previousStatus=lastStatus;
 if(previousStatus?.trial_token&&s.trial_token&&previousStatus.trial_token!==s.trial_token
    ||previousStatus?.setup_token&&s.setup_token&&previousStatus.setup_token!==s.setup_token){
  pwmControl?.cancel();
  held.clear();heartbeatDue=false;urgentGeneration++;needsRelease=true;stopPending=false;
  gamepadControl?.requireNeutral();requestError='';localHint='';el('bench-ready').checked=false;
 }
 lastStatus=s;
 pwmControl?.update(s);
 el('test-mode-section').hidden=!s.boot_test;
 if(s.test_mode)el('test-mode').value=s.test_mode;
 el('test-mode').disabled=!(s.boot_test&&s.boot_test_phase==='esc_off'&&s.mode==='disabled');
 el('drive-finish').hidden=!(s.boot_test&&s.boot_test_phase==='ready');
 if(s.control_session_id&&s.control_session_id!==pageSession){expiredPage();return;}
 if(stale)return;
 if(s.boot_test&&s.boot_test_phase!=='ready'){
  const phase=s.boot_test_phase, checking=['baseline','confirming','closing'].includes(phase), failed=s.mode==='fault', pwmMode=s.test_mode==='steering_pwm';
  allowed=false;held.clear();heartbeatDue=false;needsRelease=true;
  turnAvailable=false;motorAvailable=false;reverseAvailable=false;
  const longControl=s.ground_continuous_trial===true;
  el('drive-title').textContent=pwmMode?'S3 实时 PWM 调试':longControl?'5G 长距离遥控':'5G 一键测试';el('drive-link').textContent=checking?'正在准备':'已连接';
  el('drive-mode').textContent=s.reason;el('drive-latency').textContent=latency==null?'—':latency+' ms';
  el('drive-speed').disabled=true;el('drive-speed-value').textContent='固定低档位';
  el('drive-speed-note').textContent=longControl?'固定低档位；启用后可持续遥控，不设轮次或行驶时长限制。':'准备完成后使用已验证的低档位；每轮 60 秒，可重复开始下一轮。';
  el('drive-action').textContent='等待现场确认';el('drive-active-speed').textContent='尚未启用行驶';
  el('drive-time').textContent=phase==='baseline'?'检查约需 30～45 秒，请保持电调关闭。':phase==='esc_on'?'打开电调并确认静止后，点击启用；随后等待 '+(s.startup_settling_s??12)+' 秒。':'行驶倒计时尚未开始。';
  el('drive-limits').textContent=longControl?'W/S 或上下键持续前进、倒车；A/D 或左右键转向，可组合按键。松键停车，空格或 Esc 急停。':'W 前进每次最多 0.8 秒，A/D 转向；松键停车，空格急停。';
  el('bench-confirm-text').textContent=phase==='esc_on'?'电调已打开，车轮静止，手已移开转向机构和车轮':'电调已关闭，车已落地，场地空旷，有人能立即关闭电调';
  el('bench-ready').disabled=checking;el('drive-enable').disabled=enabling||checking||failed;
  el('drive-enable').textContent=phase==='esc_off'?'准备测试':phase==='esc_on'?'启用键盘测试':'正在准备……';
  if(pwmMode){
   el('drive-speed-section').hidden=true;
   el('drive-speed-note').textContent='仅调 S3，每次最多 2 秒；电调保持关闭。';
   el('drive-limits').textContent='1550–1750 μs，每次试调最多 2 秒，结束回原中位；不自动保存标定。';
   el('bench-confirm-text').textContent='电调已关闭，车轮已架空，手已移开车轮和转向机构';
   el('drive-enable').textContent=phase==='esc_off'?'准备 S3 调试':phase==='steering_ready'?'启用 S3 调试':'正在准备……';
   el('drive-time').textContent=phase==='baseline'?'检查约需 30～45 秒，请保持电调关闭。':phase==='steering_ready'?'保持电调关闭，确认架空后启用；随后等待 1 秒。':'尚未启用 S3 输出。';
  }else{el('drive-speed-section').hidden=false;}
  el('drive-next').hidden=true;el('drive-reset').hidden=!failed;el('drive-reset').textContent='重新准备';el('drive-focus').disabled=true;
  el('drive-safety').hidden=false;el('drive-safety').textContent=failed?'准备停止。请先关闭电调，勾选现场确认后点击“重新准备”。':phase==='esc_on'?'零油门和 5G 检查完成；现在可以打开电调，先确认车轮静止。':'先保持电调关闭，勾选现场确认后点击“准备测试”。';
  if(pwmMode&&!failed)el('drive-safety').textContent='电调全程关闭，仅 S3 转向；准备检查不发送电调、转向或云台指令。';
  if(phase==='closing')el('drive-time').textContent='正在结束当前测试，请保持车辆静止。';
  document.querySelectorAll('[data-drive],[data-speed]').forEach(b=>{b.disabled=true;b.classList.remove('active');});
  feedback(requestError||s.reason,failed?'error':checking?'sending':'ready');return;
 }
 if(s.controls_paused){
  allowed=false;held.clear();turnAvailable=false;motorAvailable=false;reverseAvailable=false;
  el('drive-title').textContent='实车控制';el('drive-link').textContent='已连接';
  el('drive-mode').textContent='模拟已关闭 · 实车暂停';
  el('drive-safety').hidden=false;el('drive-safety').textContent=s.reason;
  el('drive-action').textContent='未输出控制信号';el('drive-active-speed').textContent='0%';
  el('drive-latency').textContent=latency==null?'—':latency+' ms';
  el('drive-speed').disabled=true;el('drive-speed').value=0;el('drive-speed-value').textContent='0%';
  el('drive-speed-note').textContent='模拟操作已关闭，当前无法启用车轮或转向输出。';
  el('drive-time').textContent='供电检查通过后，重新启动实车测试。';
  el('drive-limits').textContent='电调保持关闭，摄像头预览仍可使用。';
  el('bench-ready').checked=false;el('bench-ready').disabled=true;
  el('bench-confirm-text').textContent='当前实车测试尚未就绪';
  el('drive-enable').textContent='实车暂停';el('drive-reset').hidden=true;
  ['drive-enable','drive-focus','drive-emergency','drive-stop'].forEach(id=>el(id).disabled=true);
  document.querySelectorAll('[data-drive],[data-speed]').forEach(b=>{b.disabled=true;b.classList.remove('active');});
  feedback('模拟已关闭。'+s.reason,'error');return;
 }
 const finished=['expired','closed','fault'].includes(s.mode)||s.worker_available===false;
 const nextRound=s.can_start_next_round===true;
 el('drive-next').hidden=!nextRound;el('drive-next').disabled=enabling||!el('bench-ready').checked;
 if(finished){requestError='';localHint='';held.clear();needsRelease=true;}
 const wasAllowed=allowed;allowed=s.mode==='enabled'&&!requestError&&!finished;
 pwmControl?.update(s);
 el('drive-speed-section').hidden=s.steering_pwm_available===true;
 turnAvailable=s.steering_available!==false;
 motorAvailable=s.motor_available!==false;
 reverseAvailable=s.reverse_available!==false;
 const continuous=s.continuous_simulation===true;
 const ground=s.ground_short_trial===true, groundHeld=s.ground_held_trial===true, longControl=s.ground_continuous_trial===true, testSeconds=s.test_session_s??180;
 el('drive-title').textContent=longControl?'5G 长距离遥控':groundHeld?'低速遥控测试':ground?'地面负载短测':continuous?'手动驾驶':'架空驾驶短测';
 if(s.steering_pwm_available){el('drive-title').textContent='S3 实时 PWM 调试';}
 el('drive-link').textContent='已连接';el('drive-link').style.color='#86efac';
 el('drive-latency').textContent=latency==null?'—':latency+' ms';
 el('drive-safety').hidden=!s.real_output_paused_reason;el('drive-safety').textContent='实车未启用：'+(s.real_output_paused_reason||'')+' 电调保持关闭，当前仅验证网页控制。';
 el('drive-speed').disabled=!s.speed_adjustable||stale||['closed','fault','expired'].includes(s.mode);
 document.querySelectorAll('[data-speed]').forEach(b=>b.disabled=el('drive-speed').disabled);
 if(!speedBusy&&speedWanted==null){el('drive-speed').value=s.speed_percent??100;el('drive-speed-value').textContent=el('drive-speed').value+'%';}
 el('drive-speed-note').textContent=s.speed_adjustable?'油门指令比例；实际转速尚未测量。先以低档位检查控制反馈。':'本轮实车架空短测使用已验证固定档位，速度调节暂不开放。';
 el('drive-action').textContent=s.mode==='emergency'?'已急停':(s.motor_direction==='forward'?'前进':s.motor_direction==='reverse'?'倒车':'停车')+' · '+(s.steering_direction==='left'?'左转':s.steering_direction==='right'?'右转':'回正');
 el('drive-active-speed').textContent=(s.active_speed_percent??0)+'%'+(!s.hardware_output?'（模拟）':'');
 el('bench-confirm-text').textContent=s.hardware_output?(motorAvailable?'车轮已架空，电调已打开且轮子静止，开关在手边':'车轮已架空，电调保持关闭，只测试前轮转向'):'我确认这是模拟模式，电调保持关闭';
 if(ground){el('bench-confirm-text').textContent='场地空旷，电调已打开且车轮静止，开关在手边';el('drive-active-speed').textContent=s.motor_pulse_us===1500?'零油门':'固定短测档';el('drive-speed-value').textContent='固定档位';el('drive-speed-note').textContent='使用已验证的固定油门档位，每段转动最长0.8秒。';}
 if(ground&&s.load_probe){el('drive-speed-value').textContent='起步提高一档';el('drive-speed-note').textContent='前进油门提高一档，等待本次负载验证；每段最长0.8秒，松键停车。';el('drive-active-speed').textContent=s.motor_pulse_us===1500?'零油门':'起步试验档';}
 if(s.raised_load_probe){el('drive-title').textContent='架空起步油门短测';el('drive-speed-value').textContent='前进提高一档';el('drive-speed-note').textContent='只测架空前进与停车，每段最多0.8秒；倒车和舵机信号关闭。';el('drive-active-speed').textContent=s.motor_pulse_us===1500?'零油门':'提高一档';}
 if(groundHeld){el('bench-confirm-text').textContent='车已落地，路线空旷，有人跟车，电调打开后车轮静止';el('drive-speed-value').textContent='固定低档位';el('drive-speed-note').textContent='使用已验证的低档位，松开行驶键停车。';el('drive-active-speed').textContent=s.motor_pulse_us===1500?'零油门':'固定低档位';}
 el('drive-limits').textContent=s.parking_protection_trial?'只测试 W 前进和停车保护，每次最多 0.8 秒。轮子开始转动后立即触发指定保护；先不测试倒车和转向。':motorAvailable?'前进每次最多 0.8 秒；倒车请按住约 3 秒，包含刹车和回零等待。一直按住不会重复试转，需全部松开后再按。':'只测试 A/D 或左右键，每次最多 2 秒；松键后回正并关闭舵机信号。前进、倒车和云台信号保持关闭。';
 if(continuous)el('drive-limits').textContent='按住 W/S 或上下键持续发送行驶请求，A/D 可同时转向。松开行驶键停车，空格急停；切换窗口后停止发送。';
 if(ground)el('drive-limits').textContent=reverseAvailable?'有限地面负载短测：W前进最多0.8秒，S请按住约3秒完成倒车准备。每组之间松开全部方向键；松键回零、空格急停。':'W前进最多0.8秒，A/D转向。每组之间松开全部方向键；松键回零、空格急停。';
 if(groundHeld)el('drive-limits').textContent='按住 W 前进，A/D 转向；松开 W 停车，松开转向键回正。空格急停，失联停车；单次按住最多 '+s.motion_hold_max_s+' 秒，本轮 '+testSeconds+' 秒。';
 if(longControl)el('drive-limits').textContent='按住 W/S 或上下键持续行驶，A/D 或左右键可同时转向；松开行驶键停车，松开转向键回正。空格或 Esc 急停；倒车包含刹车和回零等待。';
 el('drive-mode').textContent=(s.hardware_output?(s.parking_protection_trial?'实车停车保护短测（只测前进，舵机信号关闭）':s.combined_trial?'实车联动短测（云台信号关闭）':!motorAvailable?'实车转向短测（驱动和云台信号关闭）':turnAvailable?'实车短测':'实车车轮短测（转向和云台信号关闭）'):'模拟模式（按钮不会驱动车轮）')+' · '+s.reason+
 (s.mode==='settling'?'（'+Math.ceil(s.ready_in_s)+'秒）':'');
 if(ground)el('drive-mode').textContent='实车地面负载短测 · '+s.reason+(s.mode==='settling'?'（'+Math.ceil(s.ready_in_s)+'秒）':'');
 if(groundHeld)el('drive-mode').textContent='实车低速遥控 · '+s.reason+(s.mode==='settling'?'（'+Math.ceil(s.ready_in_s)+'秒）':'');
 if(s.raised_load_probe){el('drive-mode').textContent='实车架空前进短测 · '+s.reason+(s.mode==='settling'?'（'+Math.ceil(s.ready_in_s)+'秒）':'');el('drive-limits').textContent='只测 W 前进和停车：每次最多0.8秒，松键或空格停车；先不测试倒车和转向。';}
 el('drive-enable').disabled=enabling||s.mode!=='disabled';el('drive-enable').textContent=enabling||s.mode==='starting'?'正在启用……':groundHeld?'启用低速遥控':continuous?'启用模拟驾驶':'启用短测';el('drive-reset').hidden=s.mode!=='emergency';
 el('drive-time').textContent=s.session_remaining_s==null?(s.hardware_output?'测试剩余时间暂不可用，请关闭电调。':'当前为模拟测试'):(s.session_phase==='preparing'?'准备剩余 '+Math.ceil(s.session_remaining_s)+' 秒；启用后另有 3 分钟测试时间':(s.combined_trial||s.parking_protection_trial)&&s.mode==='settling'?'正在等待就绪；就绪后有 3 分钟测试时间':('本轮剩余 '+Math.ceil(s.session_remaining_s)+' 秒；结束后需重新准备'));
 if((ground||groundHeld)&&s.session_remaining_s!=null)el('drive-time').textContent=s.session_phase==='preparing'?'准备剩余 '+Math.ceil(s.session_remaining_s)+' 秒；启用就绪后有 '+testSeconds+' 秒测试时间':s.mode==='settling'?'正在等待就绪；就绪后有 '+testSeconds+' 秒测试时间':'本轮剩余 '+Math.ceil(s.session_remaining_s)+' 秒';
 if(groundHeld&&s.pending_hardware_start)el('drive-time').textContent='准备就绪，等待你点击启用；就绪后有 '+Math.round(testSeconds/60)+' 分钟测试时间。';
 if(groundHeld&&s.mode==='starting')el('drive-time').textContent='正在准备控制信号，请保持车辆静止；行驶倒计时尚未开始。';
 if(s.repeatable_trials&&s.pending_hardware_start)el('drive-time').textContent='等待你点击启用；每轮 '+testSeconds+' 秒，正常结束后可开始下一轮。';
 if(s.repeatable_trials&&s.mode==='starting')el('drive-time').textContent='正在准备本轮，请保持车辆静止；倒计时尚未开始。';
 if(s.raised_load_probe&&s.session_remaining_s!=null)el('drive-time').textContent=s.session_phase==='preparing'?'准备剩余 '+Math.ceil(s.session_remaining_s)+' 秒；启用就绪后有 '+testSeconds+' 秒测试时间':s.mode==='settling'?'正在等待就绪；就绪后有 '+testSeconds+' 秒测试时间':'本轮剩余 '+Math.ceil(s.session_remaining_s)+' 秒';
 if(longControl){
  el('drive-time').textContent=s.mode==='starting'?'正在准备持续遥控，请保持车辆静止。':s.mode==='settling'?'正在等待就绪：'+Math.ceil(s.ready_in_s)+' 秒。':'持续遥控模式：不设轮次和行驶时长限制；松键、失联或切换窗口时停车。';
  el('drive-enable').textContent=enabling||s.mode==='starting'?'正在启用……':'启用持续遥控';
 }
 if(finished){
  el('drive-link').textContent=s.mode==='expired'?'本轮已结束':'控制已停止';el('drive-link').style.color='#fbbf24';
  el('drive-time').textContent=s.mode==='expired'&&s.session_phase==='preparing'?'准备窗口已结束，尚未启用本轮测试。请关闭电调，重新准备。':'本轮控制已结束，请关闭电调，重新准备。';
  el('drive-active-speed').textContent='输出已结束';
  if(!nextRound||previousStatus?.mode!=='expired')el('bench-ready').checked=false;
 }
 if(nextRound){el('drive-time').textContent='第 '+s.trial_number+' 轮已结束，确认停稳后点击“开始下一轮”。';el('bench-confirm-text').textContent='车已停稳，场地空旷，电调开关在手边';}
 if(s.steering_pwm_available){
  el('bench-confirm-text').textContent=!s.boot_test&&!s.hardware_output?'我确认这是模拟 S3 模式，不连接车辆':'电调已关闭，车轮已架空，手已移开转向机构';
  el('drive-enable').textContent='启用 S3 调试';
  el('drive-limits').textContent='S3 范围 1550–1750 μs；每次试调最多 2 秒，结束回原中位。松键、空格或 Esc、切换窗口和失联时停止。';
  if(!finished)el('drive-time').textContent=s.session_remaining_s==null?'等待你确认并启用 S3 调试。':s.session_phase==='preparing'?'准备剩余 '+Math.ceil(s.session_remaining_s)+' 秒；启用后本轮 120 秒。':'S3 本轮剩余 '+Math.ceil(s.session_remaining_s)+' 秒；每次试调最多 2 秒。';
 }
 el('bench-ready').disabled=finished&&!nextRound;el('drive-focus').disabled=finished;
 el('drive-next').disabled=enabling||!el('bench-ready').checked;
 document.querySelectorAll('[data-drive]').forEach(b=>b.disabled=!allowed||!turnAvailable&&['left','right'].includes(b.dataset.drive)||!motorAvailable&&['forward','reverse'].includes(b.dataset.drive)||!reverseAvailable&&b.dataset.drive==='reverse');
 document.querySelectorAll('[data-drive]').forEach(b=>b.classList.toggle('active',Array.from(held.values()).includes(b.dataset.drive)));
 if(wasAllowed&&!allowed){held.clear();heartbeatDue=false;urgentGeneration++;needsRelease=true;}
 if(requestError){feedback(requestError,'error');return;}
 if(enabling){feedback('启用请求已发出，等待树莓派确认……','sending');return;}
 if(s.mode==='starting'){feedback('正在准备遥控，请保持车辆静止；完成后再等待就绪倒计时。','sending');return;}
 if(s.mode==='settling'){feedback('启用成功，'+(!s.hardware_output?'模拟模式，电调保持关闭':motorAvailable?'保持零油门':'电调保持关闭')+'：'+Math.ceil(s.ready_in_s)+' 秒后可以按键。','sending');return;}
 if(nextRound){feedback('本轮已结束。确认车已停稳，勾选就绪后点击“开始下一轮”。','ready');return;}
 if(s.mode==='expired'||s.mode==='closed'||s.mode==='fault'){feedback(s.reason+'；本轮不能继续按键，请关闭电调。','error');return;}
 if(s.mode==='emergency'){feedback('已急停：'+s.reason+'。需要解除急停并重新启用。','error');return;}
 if(localHint){feedback(localHint,'sending');return;}
 if(stopPending){feedback('已收到松键／停车操作，正在等待停车确认……','sending');return;}
 if(s.steering_pwm_active){feedback('S3 试调：目标 '+s.steering_pwm_requested_us+' μs，已下发 '+s.steering_pulse_us+' μs；最多 2 秒，结束回原中位。','ready');return;}
 if(s.motor_stage==='brake'){feedback((s.hardware_output?'倒车准备：正在输出刹车信号':'模拟倒车准备：刹车阶段')+'；请继续按住 S，松键会取消。','sending');return;}
 if(s.motor_stage==='neutral_gap'){feedback('倒车准备：回零等待 '+Math.max(0,s.reverse_wait_remaining_s).toFixed(1)+' 秒；请继续按住 S。','sending');return;}
 if(s.motor_pulse_us!==1500&&s.motor_pulse_us!=null){
  const centerUs=s.steering_center_us??1650;
  const turn=s.combined_trial&&s.steering_signal_active&&s.steering_pulse_us!==centerUs?'＋'+(s.steering_pulse_us>centerUs?'左转':'右转'):'';
  feedback(s.hardware_output?('树莓派已输出'+(s.motor_pulse_us>1500?'前进':'倒车')+turn+'信号；松键停车、回正。'):('模拟驾驶：'+(s.motor_direction==='forward'?'前进':'倒车')+' '+s.speed_percent+'%'+(s.steering_direction!=='center'?' ＋ '+directionNames[s.steering_direction]:'')+'；松开行驶键停车。'),'ready');return;
 }
 if((!motorAvailable||s.combined_trial)&&s.steering_signal_active){
  const centerUs=s.steering_center_us??1650;
  feedback(held.size&&!s.release_required?'树莓派已输出'+(s.steering_pulse_us===centerUs?'回正':s.steering_pulse_us>centerUs?'左转':'右转')+'信号；松键回正。':'已收到回正请求，前轮正在回正……','ready');return;
 }
 if(continuous&&s.steering_direction!=='center'&&!s.release_required){feedback('模拟驾驶：停车 ＋ '+directionNames[s.steering_direction]+'；车轮不会转动。','ready');return;}
 if(held.size&&s.release_required){feedback(continuous?'已停止行驶请求，请松开按键后再按。':'本次短测已回零，请松开按键后再测。','ready');return;}
 if(held.size){feedback('按键已收到，等待树莓派响应／回零准备……','sending');return;}
 if(allowed&&s.steering_pwm_available){feedback('S3 试调已就绪；滑条、整数输入和微调按钮均可使用。停止后已请求回原中位，请观察前轮。','ready');return;}
 if(allowed&&s.reverse_cancelled){feedback('倒车准备已因松键取消；已回零，请观察车轮是否停下。再测时按住 S 约 3 秒。','sending');return;}
 if(allowed){feedback(continuous?(['松键或停车请求','按键已松开','速度指令为零'].includes(s.reason)?'模拟停车已确认：行驶请求已回零。':'模拟驾驶已就绪：按住 W/S 行驶，A/D 转向；当前没有实车输出。'):motorAvailable?(['松键或停车请求','按键已松开'].includes(s.reason)?'已收到回零确认；请观察车轮是否停下。':'已就绪：可以按住 W 前进；当前零油门。'):['松键或停车请求','按键已松开','短测结束，请松开全部方向键后再按'].includes(s.reason)?'已输出回正信号并关闭舵机信号；请观察前轮是否回正。':'已就绪：按住 A 左转、D 右转；松键回正。','ready');return;}
 feedback('尚未启用：先勾选就绪确认，再点击“'+(s.steering_pwm_available?'启用 S3 调试':groundHeld?'启用低速遥控':continuous?'启用模拟驾驶':'启用短测')+'”。');
}

function render(s){
 if(!acceptTrafficSnapshot(s))return;
 if(typeof s.cone_status_s==='number'){if(s.cone_status_s<coneLastSnapshot)return;coneLastSnapshot=s.cone_status_s;}
 const coneDrivingBusy=renderCone(s);
 const brakeBusy=renderBrake(s),trafficBusy=renderTraffic(s); if(brakeBusy||trafficBusy||coneDrivingBusy)return;

 renderLegacy(s);
 if(s.esc_mode==='F/B'){
  el('drive-limits').textContent='F/B 模式：W 前进、A/D 转向；S / 下键及手柄倒车已禁用。遥控松键回中位；斑马线入口使用主动制动。';
  el('gamepad-arm').disabled=false;
 }
 updateReverseTrim(s);
 paintConnection(stale?'stale':'online');
 el('drive-panel').setAttribute?.('data-control-state',s.mode);
 const simple=s.boot_test&&s.esc_confirmation_only;
 el('bench-confirm-row').hidden=!!simple;
 el('drive-title').textContent=s.steering_pwm_available?'转向调试':'遥控驾驶';
 el('drive-finish').textContent='结束控制';
 if(simple){
  const phase=s.boot_test_phase;
  el('drive-enable').hidden=phase==='ready'&&s.mode!=='disabled';
  el('drive-enable').textContent=phase==='esc_off'?'电调已关闭 · 准备':phase==='esc_on'?'电调已开且静止 · 启用':phase==='steering_ready'?'电调已关且架空 · 启用':phase==='ready'?(s.steering_pwm_available?'电调已关且架空 · 启用':'电调已开且静止 · 启用'):'正在准备…';
  el('drive-reset').textContent=phase==='fault'?'电调已关闭 · 重置':'解除急停';
  el('drive-mode').textContent=({esc_off:'确认电调关闭',baseline:'检查供电与通信',esc_on:'零油门已就绪，请打开电调',steering_ready:'保持电调关闭，架空车轮',confirming:'正在启用',closing:'正在结束控制',fault:'准备失败'})[phase]||({enabled:'控制就绪',settling:'初始化 '+Math.ceil(s.ready_in_s)+' 秒',emergency:'已急停',disabled:'等待启用',fault:'控制故障',starting:'正在启动'})[s.mode]||s.mode;
 }
 if(requestError){feedback(requestError,'error');return;}
 if(localHint){feedback(localHint,'sending');return;}
 if(s.mode==='fault'||s.mode==='expired'||s.mode==='closed'){feedback(s.reason,'error');return;}
 if(s.mode==='emergency'){feedback('已急停 · 解除后重新启用','error');return;}
 if(enabling||s.mode==='starting'){feedback('正在准备，请保持车辆静止','sending');return;}
 if(s.mode==='settling'){feedback('零油门初始化 · '+Math.ceil(s.ready_in_s)+' 秒','sending');return;}
 if(stopPending){feedback('正在确认停车','sending');return;}
 if(s.steering_pwm_active){feedback('转向输出 '+s.steering_pulse_us+' μs','ready');return;}
 if(s.motor_stage==='brake'){feedback('倒车准备 · 刹车','sending');return;}
 if(s.motor_stage==='neutral_gap'){feedback((s.reverse_start_mode==='direct_after_neutral'?'换向回零 · ':'倒车准备 · ')+Math.max(0,s.reverse_wait_remaining_s||0).toFixed(1)+' 秒','sending');return;}
 if(s.motor_stage==='steering_align'){feedback('倒车前回正','sending');return;}
 if(s.boot_test&&s.boot_test_phase!=='ready'){feedback(s.boot_test_phase==='esc_on'?'打开电调后，确认车轮静止':s.boot_test_phase==='steering_ready'?'电调保持关闭':'等待电调状态确认');return;}
 if(s.mode==='enabled'){feedback(s.hardware_output?'已就绪 · '+el('drive-action').textContent:'模拟预览 · '+el('drive-action').textContent,'ready');return;}
 feedback('等待启用');
}


function trimReady(){
 return lastStatus?.reverse_trim_available===true&&lastStatus.mode==='enabled'&&allowed&&!stale&&!stopPending
  &&lastStatus.motor_direction==='stop'&&lastStatus.steering_direction==='center'
  &&held.size===0&&!pwmControl?.isActive();
}
function showTrimWanted(){
 el('reverse-trim-slider').value=reverseTrimWanted;
 el('reverse-trim-number').value=reverseTrimWanted;
 el('reverse-trim-value').textContent=(reverseTrimWanted>0?'+':'')+reverseTrimWanted+' μs';
}
function updateReverseTrim(s){
 el('reverse-trim-panel').hidden=s.reverse_trim_available!==true;
 if(!reverseTrimDirty&&!reverseTrimBusy){reverseTrimWanted=s.reverse_trim_us??0;showTrimWanted();}
 el('trim-forward-center').textContent=s.steering_center_us==null?'—':s.steering_center_us+' μs';
 el('trim-reverse-center').textContent=s.reverse_steering_center_us==null?'—':s.reverse_steering_center_us+' μs';
 const enabled=trimReady()&&!reverseTrimBusy;
 ['reverse-trim-slider','reverse-trim-number','reverse-trim-apply'].forEach(id=>el(id).disabled=!enabled);
 document.querySelectorAll('[data-reverse-trim-step]').forEach(b=>b.disabled=!enabled);
}
function chooseReverseTrim(value){
 const n=Number(value);
 if(!Number.isInteger(n)||n<-30||n>30){showTrimWanted();el('reverse-trim-note').textContent='请输入 -30 到 +30 的整数';return;}
 reverseTrimWanted=n;reverseTrimDirty=true;showTrimWanted();
 el('reverse-trim-note').textContent='尚未应用 · 点击后用于下一次倒车';
}
el('reverse-trim-slider').oninput=e=>chooseReverseTrim(e.target.value);
el('reverse-trim-number').onchange=e=>chooseReverseTrim(e.target.value);
document.querySelectorAll('[data-reverse-trim-step]').forEach(b=>b.onclick=()=>chooseReverseTrim(Math.max(-30,Math.min(30,(reverseTrimWanted??0)+Number(b.dataset.reverseTrimStep)))));
el('reverse-trim-apply').onclick=async()=>{
 if(reverseTrimBusy||!trimReady())return;
 const target=reverseTrimWanted;
 reverseTrimBusy=true;updateReverseTrim(lastStatus);
 try{
  const s=await send('reverse_trim',{sequence:++sequence,offset_us:target});
  reverseTrimDirty=false;render(s);
  el('reverse-trim-note').textContent='已应用 '+(target>0?'+':'')+target+' μs · 仅本轮有效';
 }catch(e){el('reverse-trim-note').textContent='设置未确认：'+e.message;}
 finally{reverseTrimBusy=false;updateReverseTrim(lastStatus);}
};

function stop(action='stop',keepalive=false,stopSource='unknown'){
 pwmControl?.cancel();
 gamepadControl?.requireNeutral();
 held.clear();heartbeatDue=false;localHint='';urgentGeneration++;needsRelease=true;
 if(stale)return;
 if(lastStatus&&(['expired','closed','fault'].includes(lastStatus.mode)||lastStatus.worker_available===false)){render(lastStatus);return;}
 stopPending=true;const generation=urgentGeneration;
 feedback('已收到'+(action==='emergency'?'急停':'松键／停车')+'操作，等待树莓派确认……','sending');
 document.querySelectorAll('[data-drive]').forEach(b=>b.classList.remove('active'));
 send(action,{stop_source:stopSource},keepalive).then(s=>{if(generation===urgentGeneration){requestError='';lastStatus=s;}}).catch(()=>{allowed=false;requestError='停车确认未收到：请关闭电调，检查页面连接。';feedback(requestError,'error');})
 .finally(()=>{if(generation===urgentGeneration){stopPending=false;if(lastStatus)render(lastStatus);}});
}
async function heartbeat(){
 if(coneDriveActive||coneShortActive){heartbeatDue=false;return;}
 if(trafficActive){heartbeatDue=false;return;}
 if(brakeActive){heartbeatDue=false;return;}
 if(reverseTrimBusy||stopPending||!allowed||held.size===0||stale){heartbeatDue=false;return;}
 // Two bounded requests let fresh held input cross a cellular RTT without
 // extending the configured input lease. No direction queue; release is urgent.
 // The release handshake stays serialized, including against old requests.
 const pipelined=lastStatus?.ground_continuous_trial===true;
 if(busy||motionInFlight>=(pipelined?2:1)||needsRelease&&motionInFlight){heartbeatDue=true;return;}
 const serial=!pipelined||needsRelease;
 if(serial)busy=true;
 motionInFlight++;heartbeatDue=false;const generation=urgentGeneration;
 let sentSequence=null;
 try{
  if(needsRelease){const s=await send('command',{sequence:++sequence,motor:'stop',steering:'center'});
   if(generation!==urgentGeneration||held.size===0)return;render(s);if(!allowed)return;needsRelease=false;
   commandReplySequence=sequence;if(pipelined)busy=false;}
  const values=new Set(held.values());const motor=values.has('forward')?'forward':values.has('reverse')?'reverse':'stop';
  const steering=values.has('left')?'left':values.has('right')?'right':'center';
  if(values.has('forward')&&values.has('reverse')||values.has('left')&&values.has('right')){stop('stop',false,'conflicting_keys');return;}
  const sources=Array.from(held.keys());
  sentSequence=++sequence;
  const s=await send('command',{sequence:sentSequence,motor,steering,input_source:sources.some(x=>x.startsWith('pad:'))?'gamepad':sources.some(x=>x.startsWith('key:'))?'keyboard':'pointer'});
  if(generation===urgentGeneration&&sentSequence>commandReplySequence){commandReplySequence=sentSequence;requestError='';localHint='';render(s);}
 }
 catch(e){
  // The worker rejects reordered commands without renewing their lease.
  // A valid locally generated sequence can only be old if a newer one won.
  const superseded=pipelined&&sentSequence!==null&&e.message==='old or invalid command sequence';
  if(!superseded&&generation===urgentGeneration&&!stale){held.clear();heartbeatDue=false;allowed=false;needsRelease=true;urgentGeneration++;requestError=e.message+'；控制请求失败，请关闭电调后检查。';feedback(requestError,'error');}
 }
 finally{motionInFlight--;if(serial)busy=false;if(heartbeatDue&&!stopPending&&allowed&&held.size&&!stale){heartbeatDue=false;heartbeat();}}
}
function press(source,direction){
 if(reverseTrimBusy){feedback('正在设置倒车补偿','sending');return;}
 if(pwmControl?.isActive()){localHint='请先停止 PWM 试调，再使用方向键。';if(lastStatus)render(lastStatus);return;}
 if(gamepadControl?.armed){localHint='手柄方向模式已选中；键盘空格仍可急停。使用键盘或屏幕方向前，请取消手柄勾选。';if(lastStatus)render(lastStatus);return;}
 if(stale){expiredPage();return;}
 if(!allowed){localHint='已收到'+directionNames[direction]+'按键，但尚未就绪；请先启用并等待倒计时。';if(lastStatus)render(lastStatus);return;}
 if(!turnAvailable&&['left','right'].includes(direction)){localHint='本轮只测试车轮，左右转向信号关闭。';render(lastStatus);return;}
 if(!motorAvailable&&['forward','reverse'].includes(direction)){localHint='本轮只测试转向，前进和倒车信号关闭；请按 A 或 D。';render(lastStatus);return;}
 if(!reverseAvailable&&direction==='reverse'){localHint='本轮只测试前进停车保护，倒车信号关闭；请按 W。';render(lastStatus);return;}
 if(held.has(source))return;localHint='';requestError='';held.set(source,direction);feedback('已收到'+directionNames[direction]+'按键，正在发出控制请求……','sending');heartbeat();
}
function release(source){
 if(!held.has(source))return;held.delete(source);
 if((lastStatus?.continuous_simulation||lastStatus?.raised_held_trial||lastStatus?.ground_held_trial)&&held.size){urgentGeneration++;localHint='';heartbeat();return;}
 stop('stop',false,source.startsWith('key:')?'key_release':'pointer_release');
}
async function changeSpeed(value){
 if(stale||!lastStatus?.speed_adjustable)return;
 speedWanted=Number(value);el('drive-speed').value=speedWanted;el('drive-speed-value').textContent=speedWanted+'%';
 if(speedWanted===0)stop('stop',false,'speed_zero');
 if(speedBusy)return;speedBusy=true;
 try{
  while(speedWanted!=null){const value=speedWanted;speedWanted=null;lastStatus=await send('speed',{speed_percent:value});}
 }catch(e){speedWanted=null;requestError='速度设置未确认：'+e.message;stop('stop',false,'speed_failure');}
 finally{speedBusy=false;if(lastStatus)render(lastStatus);}
}
el('drive-speed').oninput=e=>changeSpeed(e.target.value);
el('drive-speed').onpointerup=()=>el('drive-panel').focus({preventScroll:true});
document.querySelectorAll('[data-speed]').forEach(b=>b.onclick=()=>{changeSpeed(b.dataset.speed);el('drive-panel').focus({preventScroll:true});});
document.querySelectorAll('[data-drive]').forEach(b=>{
 b.style.touchAction='none';b.onpointerdown=e=>{e.preventDefault();b.setPointerCapture(e.pointerId);b.classList.add('active');press('pointer:'+e.pointerId,b.dataset.drive);};
 b.onpointerup=e=>release('pointer:'+e.pointerId);b.onpointercancel=e=>release('pointer:'+e.pointerId);
 b.onlostpointercapture=e=>release('pointer:'+e.pointerId);
});
window.addEventListener('keydown',e=>{
 if(e.code==='Space'||e.key===' '||e.key==='Spacebar'||e.key==='Escape'||e.code==='Escape'){e.preventDefault();if(!e.repeat)stop('emergency',false,e.key==='Escape'||e.code==='Escape'?'keyboard_escape':'keyboard_space');return;}
 if(keyDirection(e)){
  if(['INPUT','SELECT','TEXTAREA'].includes(e.target.tagName)){localHint='方向键已收到，请先点击页面空白处，再按键。';if(lastStatus)render(lastStatus);return;}
  e.preventDefault();if(!e.repeat)press(keySource(e),keyDirection(e));}
});
window.addEventListener('keyup',e=>{if(keyDirection(e)){e.preventDefault();release(keySource(e));}});
el('drive-stop').onclick=()=>stop('stop',false,'stop_button');el('drive-emergency').onclick=()=>stop('emergency',false,'emergency_button');
el('drive-focus').onclick=()=>{el('drive-panel').focus();localHint=allowed?(motorAvailable?'页面已获得键盘焦点：按住 W 前进，松开停车。':'页面已获得键盘焦点：按住 A 左转、D 右转，松键回正。'):'页面已获得键盘焦点；先启用短测，再按方向键。';if(lastStatus)render(lastStatus);};
el('drive-refresh').onclick=()=>window.location.reload();
el('test-mode').onchange=async()=>{
 if(stale||enabling)return;
 pwmControl?.cancel();held.clear();heartbeatDue=false;needsRelease=true;
 try{requestError='';render(await send('select_mode',{test_mode:el('test-mode').value}));}
 catch(e){requestError=e.message;if(lastStatus)render(lastStatus);}
};
el('drive-finish').onclick=async()=>{
 if(stale||enabling)return;
 pwmControl?.cancel();held.clear();heartbeatDue=false;allowed=false;needsRelease=true;urgentGeneration++;
 try{requestError='';render(await send('finish_test'));}
 catch(e){requestError=e.message;feedback('结束测试未确认：'+e.message,'error');}
};
el('drive-reconnect').onclick=async()=>{
 if(stale){window.location.reload();return;}
 if(lastStatus&&(['expired','closed','fault'].includes(lastStatus.mode)||lastStatus.worker_available===false)){render(lastStatus);return;}
 held.clear();urgentGeneration++;needsRelease=true;
 try{await send('emergency',{stop_source:'connection_recovery'});lastStatus=await send('reset');requestError='';localHint='';sequence=0;el('bench-ready').checked=false;render(lastStatus);}
 catch(e){requestError='重新连接失败：'+e.message;feedback(requestError,'error');}
};
el('bench-ready').onchange=()=>{if((lastStatus?.mode==='disabled'||lastStatus?.can_start_next_round)&&!enabling){requestError='';localHint='';render(lastStatus);}};
el('drive-next').onclick=async()=>{
 if(stale||enabling||!lastStatus?.can_start_next_round)return;
 if(!el('bench-ready').checked){feedback('请先确认车已停稳且现场就绪。','error');return;}
 enabling=true;allowed=false;held.clear();heartbeatDue=false;urgentGeneration++;needsRelease=true;
 gamepadControl?.requireNeutral();requestError='';localHint='';render(lastStatus);
 try{sequence=0;lastStatus=await send('next_trial',{bench_ready:true});el('bench-ready').checked=false;render(lastStatus);}
 catch(e){requestError='下一轮准备失败：'+e.message;feedback(requestError,'error');}
 finally{enabling=false;if(lastStatus)render(lastStatus);}
};
el('drive-enable').onclick=async()=>{
 if(stale||enabling)return;
 if(!(lastStatus?.boot_test&&lastStatus?.esc_confirmation_only)&&!el('bench-ready').checked){requestError=lastStatus?.ground_short_trial||lastStatus?.ground_held_trial?'启用未发送：请先勾选场地和电调就绪确认。':lastStatus?.continuous_simulation?'启用未发送：请先勾选模拟模式确认。':'启用未发送：请先勾选车轮架空和当前电调状态确认。';if(lastStatus)render(lastStatus);return;}
 enabling=true;requestError='';localHint='';if(lastStatus)render(lastStatus);
 try{sequence=0;held.clear();needsRelease=true;lastStatus=await send('enable',{bench_ready:true,esc_state:['esc_off','steering_ready'].includes(lastStatus?.boot_test_phase)||lastStatus?.test_mode==='steering_pwm'?'off':'on_static'});}
 catch(e){requestError='启用失败：'+e.message;feedback(requestError,'error');}
 finally{enabling=false;if(lastStatus)render(lastStatus);}};
el('drive-reset').onclick=async()=>{try{requestError='';localHint='';render(await send('reset',{bench_ready:!!(lastStatus?.boot_test&&lastStatus?.esc_confirmation_only)||el('bench-ready').checked,esc_state:'off'}));el('bench-ready').checked=false;}catch(e){requestError=e.message;feedback(requestError,'error');}};
window.addEventListener('blur',()=>stop('stop',false,'window_blur'));
document.addEventListener('visibilitychange',()=>{if(document.hidden)stop('stop',false,'page_hidden');});
window.addEventListener('pagehide',()=>stop('stop',true,'page_exit'));
async function poll(){const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),1500),started=performance.now();
 try{const response=await fetch('/api/drive/status',{cache:'no-store',signal:controller.signal});if(!response.ok)throw new Error('状态读取失败');const status=await response.json();latency=Math.round(performance.now()-started);render(status);}
 catch(e){pwmControl?.cancel();held.clear();allowed=false;requestError='控制服务连接中断，请关闭电调后检查网络。';el('drive-link').textContent='连接中断';paintConnection('offline');feedback(requestError,'error');}
 finally{clearTimeout(timer);el('drive-reconnect').hidden=!requestError||stale||lastStatus&&(['expired','closed','fault'].includes(lastStatus.mode)||lastStatus.worker_available===false);setTimeout(poll,800);}}
__GAMEPAD_CONTROLS__
__PWM_CONTROLS__
pwmControl=createSteeringPWMControls({el,
 request:(action,body)=>send(action,{sequence:++sequence,...body}),
 status:()=>({allowed:allowed&&!stopPending&&!stale,otherInput:held.size>0||el('gamepad-arm').checked}),
 render,stop:()=>stop('stop',false,'pwm_stop'),
 onError:e=>feedback('PWM 试调未确认：'+e.message,'error')});
gamepadControl=createUSBGamepadControls({arm:el('gamepad-arm'),info:el('gamepad-info'),
 getPads:typeof navigator.getGamepads==='function'?()=>navigator.getGamepads():null,
 now:()=>performance.now(),state:()=>({allowed:allowed&&!stopPending&&!reverseTrimBusy,ready:allowed,stale,
 focused:!document.hidden&&document.hasFocus(),otherInput:!!pwmControl?.isActive()||Array.from(held.keys()).some(x=>!x.startsWith('pad:')),
 capabilities:{forward:motorAvailable,reverse:motorAvailable&&reverseAvailable,left:turnAvailable,right:turnAvailable}}),
 stop:(reason,emergency)=>stop(emergency?'emergency':'stop',false,reason),
 directions:directions=>{urgentGeneration++;for(const source of Array.from(held.keys()))if(source.startsWith('pad:'))held.delete(source);
  for(const direction of directions)held.set('pad:'+direction,direction);heartbeat();}
});
setInterval(()=>gamepadControl.sample(),50);
setInterval(heartbeat,70);poll();

function renderBrake(s){
 const t=s.crosswalk_trial||{};
 if(t.brake_trigger)el('crosswalk-program-summary').textContent='第二路 H65 · 约 '+Math.round(t.brake_trigger.distance_m*100)+' cm 刹车 · 停稳 '+t.hold_s+' 秒并播报';
 if(s.control_session_id&&s.control_session_id!==pageSession){expiredPage();return true;}
 const owned=t.owner_client===client;
 brakeActive=!!t.active;
 brakeOwned=owned;
 brakeToken=t.run_token;
 brakeSettingsRevision=t.settings_revision;
 el('crosswalk-test-state').textContent=t.prepare_blocked_reason||t.reason||'未加载刹车测试程序';
 el('crosswalk-reference-state').textContent=t.reference_summary||'';
 el('crosswalk-prepare').disabled=stale||!t.can_prepare||brakeSaveBusy;
 el('crosswalk-start').disabled=stale||!owned||!t.can_start||brakeSaveBusy;
 el('crosswalk-start').textContent=t.phase==='complete'?'开始下一轮':'开始';
 el('crosswalk-path-mode').disabled=!!t.active&&!['ready','complete'].includes(t.phase);
 el('crosswalk-distance').disabled=stale||brakeSaveBusy||t.active&&!owned;
 el('crosswalk-save-distance').disabled=el('crosswalk-distance').disabled;
 if(t.brake_trigger&&!brakeSettingsDirty&&document.activeElement!==el('crosswalk-distance'))el('crosswalk-distance').value=Math.round(t.brake_trigger.distance_m*100);
 if(!brakeSettingsDirty&&!brakeSaveBusy){
  const next=Math.round((t.brake_trigger?.distance_m||0)*100),current=Math.round((t.running_brake_trigger?.distance_m||0)*100);
  el('crosswalk-settings-state').textContent=t.settings_error||(t.active&&!['ready','complete','preparing'].includes(t.phase)&&next!==current?
   '本轮保持 '+current+' cm；已保存 '+next+' cm，下轮生效。':'已保存 '+next+' cm · 可改 25–65 cm，数值越大越早刹车。');
 }
 const p=t.intent;
 el('crosswalk-intent').textContent=t.phase==='arming'?'中位初始化：'+Math.ceil(t.arming_remaining_s)+' 秒':
  p?('阶段 '+p.phase+' · 输出 '+p.esc_us+' μs'+(p.hold_remaining_s!=null?' · 等待 '+p.hold_remaining_s.toFixed(1)+' 秒':'')):'';
 el('crosswalk-speech-state').textContent=({sending:'正在发送播报',command_sent:'已发送：'+(t.speech?.text||t.speech_text||''),failed:'语音发送失败',cancelled:'语音请求已结束'})[t.speech?.state]||'';
 if(!t.active)return false;
 lastStatus=s;held.clear();heartbeatDue=false;needsRelease=true;allowed=false;
 turnAvailable=false;motorAvailable=false;reverseAvailable=false;
 gamepadControl?.requireNeutral();
 el('drive-title').textContent='斑马线刹车测试';
 el('drive-mode').textContent=t.reason;
 el('drive-action').textContent=t.phase==='brake_pulse'?'主动制动':p?.action==='search'||p?.action==='creep'?'前进':'中位';
 el('drive-active-speed').textContent=p?p.esc_us+' μs':'准备中';
 el('drive-time').textContent=owned?'本页持有测试控制权':'测试由另一页面持有';
 el('drive-latency').textContent=latency==null?'—':latency+' ms';
 for(const id of ['drive-enable','drive-reset','drive-next','drive-speed','test-mode','gamepad-arm']){if(el(id))el(id).disabled=true;}
 document.querySelectorAll('[data-drive],[data-speed]').forEach(b=>b.disabled=true);
 feedback(t.reason,t.phase==='fault'?'error':'sending');
 return true;
}
async function brakeSend(action,body={}){
 return send(action,{run_token:brakeToken,trial_sequence:++brakeSequence,...body});
}
el('crosswalk-distance').addEventListener('input',()=>{
 brakeSettingsDirty=true;el('crosswalk-settings-state').textContent='尚未保存；点击保存，或开始时自动保存。';
});
async function saveBrakeSettings(force=false){
 if(!brakeSettingsDirty&&!force)return true;
 const input=el('crosswalk-distance');
 if(!input.checkValidity()){input.reportValidity();return false;}
 brakeSaveBusy=true;if(lastStatus)render(lastStatus);
 try{
  const state=await send('crosswalk_settings',{brake_distance_cm:Number(input.value),settings_revision:brakeSettingsRevision});
  brakeSettingsDirty=false;render(state);return true;
 }catch(e){el('crosswalk-settings-state').textContent=e.message;return false;}
 finally{brakeSaveBusy=false;if(lastStatus)render(lastStatus);}
}
el('crosswalk-save-distance').addEventListener('click',()=>saveBrakeSettings(true));
el('crosswalk-prepare').addEventListener('click',async()=>{
 held.clear();needsRelease=true;gamepadControl?.requireNeutral();
 try{
  if(!await saveBrakeSettings())return;
  requestError='';localHint='';brakeSequence=0;
  render(await send('crosswalk_prepare',{esc_off:true,fb_mode_confirmed:true}));
 }catch(e){feedback(e.message,'error');}
});
el('crosswalk-start').addEventListener('click',async()=>{
 try{
  if(!await saveBrakeSettings())return;
  requestError='';localHint='';
  render(await brakeSend('crosswalk_start',{field_ready:true,esc_on_static:true,fb_mode_confirmed:true,path_mode:el('crosswalk-path-mode').value}));
 }catch(e){feedback(e.message,'error');}
});
el('crosswalk-cancel').addEventListener('click',()=>stop('stop',false,'stop_button'));
setInterval(async()=>{
 if(!brakeActive||!brakeOwned||stale||document.hidden||brakePulseBusy>=2)return;
 brakePulseBusy++;
 try{render(await brakeSend('crosswalk_keepalive'));}
 catch(e){if(e.message!=='old or invalid brake sequence'){feedback(e.message,'error');stop('stop',false,'connection_recovery');}}
 finally{brakePulseBusy--;}
},100);

function acceptTrafficSnapshot(s){
 if(s.control_session_id&&s.control_session_id!==pageSession){expiredPage();return false;}
 const at=s.traffic_status_s;
 if(typeof at==='number'&&Number.isFinite(at)){
  if(at<trafficLastStatusAt)return false;
  trafficLastStatusAt=at;
 }
 return true;
}
function renderTraffic(s){
 const t=s.traffic_trial||{}, cfg=t.settings||{}, own=t.owner_client===client;
 const wasActive=trafficActive;
 trafficActive=!!t.active;trafficOwned=own;trafficToken=t.run_token;trafficSettingsRevision=t.settings_revision;
 el('traffic-test-state').textContent=t.settings_error||t.reason||'红绿灯程序未加载';
 el('traffic-prepare').disabled=stale||trafficSaveBusy||!t.can_prepare;
 const startDisabled=stale||trafficSaveBusy||trafficStartBusy||!own||!(t.can_request_start??t.can_start);
 if(el('traffic-start').disabled!==startDisabled)el('traffic-start').disabled=startDisabled;
 const startLabel=trafficStartBusy?'正在开始…':t.phase==='complete'?'开始下一轮':'开始';
 if(el('traffic-start').textContent!==startLabel)el('traffic-start').textContent=startLabel;
 const startReason=stale?'页面已过期，请刷新后重新准备':trafficSaveBusy?'正在保存参数':
  t.active&&!own?'这一轮由另一页面准备；请使用原页面，或先停止本轮':t.start_blocked_reason||'';
 el('traffic-start').title=startReason;
 el('traffic-start-hint').textContent=trafficStartError||startReason||(t.camera_ready?'准备完成：无需看见灯具，打开电调并确认静止后点开始。':'等待准备');
 for(const id of ['traffic-forward','traffic-approach','traffic-red-percent','traffic-save'])el(id).disabled=stale||trafficSaveBusy||!!t.active;
 const forward=el('traffic-forward');
 if(t.forward_limits_us){forward.min=t.forward_limits_us[0];forward.max=t.forward_limits_us[1];}
 if(!trafficDirty&&!trafficSaveBusy&&cfg.pwm){
  el('traffic-forward').value=cfg.pwm.search_us;el('traffic-approach').value=cfg.max_approach_s;
  el('traffic-red-percent').value=cfg.red_confirm_percent;
  el('traffic-settings-state').textContent='已保存 · '+cfg.pwm.search_us+' μs · 两路各统计 2 秒，红／绿共用 '+cfg.red_confirm_percent+'% · 红灯优先。';
 }
 el('traffic-forward-down').disabled=forward.disabled||Number(forward.value)<=Number(forward.min);
 el('traffic-forward-up').disabled=forward.disabled||Number(forward.value)>=Number(forward.max);
 const obs=t.observation, raw=obs?.signal, p=t.intent;
 const fresh=t.active&&t.frame_age_s!=null&&t.frame_age_s>=0&&t.frame_age_s<=.25;
 const color=fresh?(p?.signal_votes?.state||raw?.state):'unknown';
 el('traffic-color').textContent=({red:p?.red_seen_this_round?'红灯已确认 · 停车':'红灯候选 · 待比例确认',yellow:'黄灯 · 停车',green:'绿灯',off:t.can_start?'灯具未亮 · 可开始搜索':p?.phase==='approach'?'未亮 · 正在接近':'熄灯 · 等待',unknown:t.can_start?'未见灯具 · 可开始搜索':p?.phase==='approach'?'未见灯具 · 搜索中':'未确认灯色'})[color]||'等待画面';
 el('traffic-color').dataset.signal=color;
 el('traffic-vision').textContent=fresh?Object.entries(obs.camera_observations||{}).map(([c,v])=>(c==='primary'?'第一路':'第二路 H65')+' #'+v.frame_id+' '+v.signal.state).join(' · '):'准备后显示双路识别；旧画面不作为依据';
 el('traffic-intent').textContent=t.active&&p?('阶段 '+p.phase+' · 输出 '+p.esc_us+' μs'+(p.red_seen_this_round?' · 已见本轮红灯':'')+(p.stable?.green_confirmed?' · 绿灯占比已达标':'')):'';
 el('traffic-intent').hidden=!t.active||!p;
 const votes=p?.signal_votes;
 el('traffic-red-vote').textContent=t.active&&votes?Object.entries(votes.cameras).map(([c,v])=>(c==='primary'?'第一路':'第二路')+'：'+(!v.valid?'画面不可用，不参与计票':('红 '+v.red_frames+'/'+v.total_frames+' = '+v.red_percent.toFixed(1)+'% · 绿 '+v.green_frames+'/'+v.total_frames+' = '+v.green_percent.toFixed(1)+'%'+(!v.ready?' · 收集窗口 '+v.collected_s.toFixed(1)+'/2 秒':'')))).join(String.fromCharCode(10))+String.fromCharCode(10)+'共用阈值 '+votes.threshold_percent+'%'+(votes.conflict?' · 红绿同时达标，红灯优先':''):'开始后显示两路各自的红／绿帧占比；绿灯也使用相同2秒窗口及比例。';
 el('traffic-speech-state').textContent=({sending:'正在发送播报',command_sent:'已发送：红绿灯结束，开始前行',failed:'语音发送失败；车辆仍保持停车',cancelled:'播报已结束'})[t.speech?.state]||'';
 el('traffic-speech-state').hidden=!el('traffic-speech-state').textContent;
 if(t.active&&!wasActive)el('traffic-preview-section').open=true;
 if(!fresh){el('traffic-preview').hidden=true;el('traffic-preview-placeholder').hidden=false;el('traffic-preview-placeholder').textContent=t.active?'画面暂未更新，等待新帧':'准备后显示双路识别：左第一路，右第二路 H65';}
 if(!t.active)return false;
 lastStatus=s;held.clear();heartbeatDue=false;needsRelease=true;allowed=false;
 turnAvailable=false;motorAvailable=false;reverseAvailable=false;gamepadControl?.requireNeutral();
 el('drive-title').textContent='红绿灯场地测试';el('drive-mode').textContent=t.reason;
 el('drive-action').textContent=p?.action==='brake'?'主动制动':p?.action==='search'?'前进':'中位';
 el('drive-active-speed').textContent=p?p.esc_us+' μs':'准备中';
 el('drive-time').textContent=own?'本页持有红绿灯控制权':'另一页面正在测试';
 el('drive-latency').textContent=latency==null?'—':latency+' ms';
 for(const id of ['drive-enable','drive-reset','drive-next','drive-speed','test-mode','gamepad-arm','drive-focus']){if(el(id))el(id).disabled=true;}
 document.querySelectorAll('[data-drive],[data-speed]').forEach(b=>b.disabled=true);
 feedback(t.reason,t.phase==='fault'?'error':'sending');return true;
}
async function trafficSend(action,body={}){
 return send(action,{run_token:trafficToken,trial_sequence:++trafficSequence,...body});
}
for(const id of ['traffic-forward','traffic-approach','traffic-red-percent'])el(id).addEventListener('input',()=>{
 trafficDirty=true;el('traffic-settings-state').textContent='尚未保存；准备前会自动保存。';
});
function adjustTrafficForward(delta){
 const input=el('traffic-forward');if(input.disabled)return;
 const value=Number(input.value);
 input.value=Math.min(Number(input.max),Math.max(Number(input.min),(Number.isFinite(value)?value:1600)+delta));
 input.dispatchEvent(new Event('input',{bubbles:true}));
 if(lastStatus)render(lastStatus);
}
el('traffic-forward-down').addEventListener('click',()=>adjustTrafficForward(-5));
el('traffic-forward-up').addEventListener('click',()=>adjustTrafficForward(5));
async function saveTrafficSettings(force=false){
 if(!trafficDirty&&!force)return true;
 for(const id of ['traffic-forward','traffic-approach','traffic-red-percent']){if(!el(id).checkValidity()){el(id).reportValidity();return false;}}
 trafficSaveBusy=true;if(lastStatus)render(lastStatus);
 try{
  const s=await send('traffic_settings',{settings_revision:trafficSettingsRevision,forward_us:Number(el('traffic-forward').value),max_approach_s:Number(el('traffic-approach').value),red_confirm_percent:Number(el('traffic-red-percent').value)});
  trafficDirty=false;render(s);return true;
 }catch(e){el('traffic-settings-state').textContent=e.message;return false;}
 finally{trafficSaveBusy=false;if(lastStatus)render(lastStatus);}
}
el('traffic-save').addEventListener('click',()=>saveTrafficSettings(true));
el('traffic-prepare').addEventListener('click',async()=>{
 held.clear();needsRelease=true;gamepadControl?.requireNeutral();
 try{
  if(!await saveTrafficSettings())return;
  requestError='';localHint='';trafficStartError='';trafficSequence=0;
  render(await send('traffic_prepare',{esc_off:true,fb_mode_confirmed:true}));
 }catch(e){feedback(e.message,'error');}
});
el('traffic-start').addEventListener('click',async()=>{
 if(trafficStartBusy)return;
 trafficStartBusy=true;trafficStartError='';if(lastStatus)render(lastStatus);
 try{requestError='';localHint='';render(await trafficSend('traffic_start',{fb_mode_confirmed:true,esc_on_static:true,field_ready:true}));}
 catch(e){trafficStartError=e.message;feedback(e.message,'error');}
 finally{trafficStartBusy=false;if(lastStatus)render(lastStatus);}
});
el('traffic-cancel').addEventListener('click',()=>stop('stop',false,'stop_button'));
setInterval(async()=>{
 if(!trafficActive||!trafficOwned||stale||document.hidden||trafficPulseBusy>=2)return;
 trafficPulseBusy++;
 try{render(await trafficSend('traffic_keepalive'));}
 catch(e){if(e.message!=='old or invalid traffic sequence'){feedback(e.message,'error');stop('stop',false,'connection_recovery');}}
 finally{trafficPulseBusy--;}
},100);
let trafficImageBusy=false,trafficImageURL=null;
setInterval(async()=>{
 if(!trafficActive||stale||document.hidden||trafficImageBusy)return;
 trafficImageBusy=true;const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),1500);
 try{
  const r=await fetch('/api/traffic/frame.jpg',{cache:'no-store',signal:controller.signal});if(!r.ok)throw new Error('no fresh frame');
  const url=URL.createObjectURL(await r.blob()),old=trafficImageURL;trafficImageURL=url;
  el('traffic-preview').src=url;el('traffic-preview').hidden=false;el('traffic-preview-placeholder').hidden=true;if(old)URL.revokeObjectURL(old);
 }catch(e){el('traffic-preview').hidden=true;el('traffic-preview-placeholder').hidden=false;}
 finally{clearTimeout(timer);trafficImageBusy=false;}
},400);

function renderCone(s){
 const c=s.cone_trial||{};coneActive=!!c.observing;
 const a=c.avoidance||{};coneDriveActive=!!a.active;coneDriveOwned=a.owner_client===client;coneToken=a.run_token;
 const q=c.short_test||{},qo=q.output||{};
 el('cone-surface').disabled=el('cone-save-surface').disabled=stale||coneBusy||coneActive||coneDriveActive||!!q.active;
 if(!coneDirty&&!coneBusy&&c.settings)el('cone-surface').value=c.settings.scene?.surface||'red_running_track';
 coneShortActive=!!q.active;coneShortOwned=q.owner_client===client;coneShortToken=q.run_token;coneShortRound=q.round??0;
 el('cone-short-prepare').disabled=stale||coneBusy||!q.can_prepare;
 const shortLocked=stale||coneBusy||coneShortStartBusy||!q.can_start||!coneShortOwned;
 for(const id of ['cone-short-1570','cone-short-1650','cone-short-brake'])el(id).disabled=shortLocked;
 for(const id of ['cone-short-forward','cone-short-duration'])el(id).disabled=stale||coneShortStartBusy||(coneShortActive&&(!q.can_start||!coneShortOwned));
 el('cone-short-state').textContent=q.reason||'短测模块尚未加载';
 el('cone-short-output').textContent=q.active||q.round?('第 '+(q.round??0)+' 轮 · S3 '+(qo.steering_us??'—')+' μs · S4 '+(qo.esc_us??'—')+' μs'+(qo.phase==='driving'?' · 前进剩余 '+qo.remaining_s.toFixed(2)+' 秒':'')+(qo.brake_count?' · 刹车脉冲 '+qo.brake_count+'/3':'')):'';
 el('cone-short-evidence').textContent=qo.brake_started_s!=null?'本轮制动触发已记录。程序结束不代表已经实测停稳；请量实际停止位置。':'记录车端前进、制动触发时刻及对应画面；不自动填写标定值。';
 el('cone-state').textContent=coneError||c.reason||'锥桶模块未加载';
 el('cone-observe').disabled=stale||coneBusy||!c.can_observe;
 el('cone-stop').disabled=stale||coneBusy||!coneActive;
 for(const id of [...coneInputs,'cone-save','cone-save-dimensions','cone-save-driving','cone-save-calibration','cone-calibration-json','cone-steering-verified','cone-odometry-verified'])el(id).disabled=stale||coneBusy||coneActive||coneDriveActive;
 el('cone-prepare').disabled=stale||coneBusy||!a.can_prepare;
 el('cone-drive-start').disabled=stale||coneBusy||!coneDriveOwned||!a.can_request_start;
 el('cone-drive-start').title=a.start_blocked_reason||'';
 el('cone-run-state').textContent=a.reason||'尚未准备避障';
 const nav=c.latest?.navigation,phases={needs_calibration:'待标定',calibration_only:'位移标定观察',waiting_for_feedback:'等待反馈',waiting_for_two_cones:'等待确认前方两只锥桶',pass_first_cone:'按指定侧绕第一桶',pass_second_cone:'换边绕第二桶',follow_lane:'低速循迹',avoid_cones:'绕行锥桶',return_to_lane:'回归赛道',waiting_for_clear_route:'没有可通过路线',complete:'交错绕桶完成',fault:'已停止'};
 const slalom=nav?.slalom||a.slalom;
 const slalomReasons={cones_too_close_for_alternation:'两桶前后间距不足，无法安排有顺序的换边',need_two_confirmed_cones_ahead:'需要先确认前方两只锥桶',no_feasible_alternating_route:'当前桶距、边界、视野或转弯半径不支持交错路线',slalom_wrong_side_or_clearance:'通过侧别或净空不符合要求',slalom_pose_discontinuity:'位移反馈不连续，请重新准备',slalom_cone_position_changed:'锥桶位置发生变化，请重新准备',slalom_wrong_order:'通过顺序不符合要求',slalom_pass_without_ordered_side_evidence:'缺少按顺序交错通过的位姿证据',slalom_reference_tracking_error:'车辆偏离选定路线，请重新准备',slalom_reference_view_unavailable:'选定路线超出当前可信视野',slalom_reference_blocked:'选定路线的车身净空或白线边界不满足要求',following_locked_alternating_route:'正在跟随选定交错路线',alternating_cones_passed_and_lane_recovered:'两桶已交错通过并回正',no_lane_recovery_route:'暂时没有可行的回正路线'};
 el('cone-slalom').textContent=slalom?.order?.length?('本轮顺序：'+slalom.order.map((p,i)=>(i+1)+'号桶（'+p.id+'）从'+(p.side==='left'?'左':'右')+'侧通过').join(' → ')+' · 已核验 '+(slalom.passed_ids?.length||0)+'/2'+(nav?.reason?' · '+(slalomReasons[nav.reason]||nav.reason):'')):(slalomReasons[nav?.reason]||'等待确认两只锥桶及交错路线');
 el('cone-navigation').textContent=nav?((phases[nav.phase]||nav.phase)+' · '+(nav.reason||'')+(nav.side?' · 路线 '+({left:'向左',right:'向右',center:'居中'}[nav.side]||nav.side):'')+(nav.passed_ids?' · 已过 '+nav.passed_ids.length+'/2':'')+(nav.motion?.valid?' · 速度 '+nav.motion.speed_mps.toFixed(3)+' m/s · 位移 '+nav.motion.travel_m.toFixed(2)+' m':'')):'开始识别后显示选路、位移和通过计数';
 document.querySelectorAll('[data-cone-drive],[data-cone-motion]').forEach(input=>{
  input.disabled=stale||coneBusy||coneActive||coneDriveActive;
  if(!coneDirty&&!coneBusy&&c.settings){const v=input.dataset.coneDrive?c.settings.driving[input.dataset.coneDrive]:c.settings.motion[input.dataset.coneMotion+'_m'];input.value=v==null?'':input.dataset.coneDrive?v:Math.round(v*1000)/10;}
 });
 if(!coneDirty&&!coneBusy&&c.settings){el('cone-steering-verified').checked=!!c.settings.driving.steering_verified;el('cone-odometry-verified').checked=!!c.settings.driving.odometry_verified;}
 document.querySelectorAll('[data-cone-geometry]').forEach(input=>{
  input.disabled=stale||coneBusy||coneActive;
  if(!coneDirty&&!coneBusy&&c.settings){const v=c.settings.geometry[input.dataset.coneGeometry];input.value=v==null?'':Math.round(v*1000)/10;}
 });
 if(!coneDirty&&!coneBusy&&c.settings){
  const p=c.settings;[p.blue_hsv_lower[0],p.blue_hsv_upper[0],p.blue_hsv_lower[1],p.blue_hsv_lower[2],p.confirm_frames,Math.round((p.scene?.red_ground_min_fraction??.15)*100)].forEach((v,i)=>el(coneInputs[i]).value=v);
 }
 const fresh=coneActive&&c.frame_age_s!=null&&c.frame_age_s>=0&&c.frame_age_s<=.25;
 el('cone-cameras').textContent=fresh?Object.entries(c.latest?.cameras||{}).map(([key,v])=>{
  const visible=v.tracks.filter(t=>t.visible),confirmed=visible.filter(t=>t.confirmed&&t.kind==='cone_candidate');
  return (key==='secondary'?'第二路 H65':'第一路')+'：已确认 '+confirmed.length+' 个，待判断 '+visible.filter(t=>t.kind==='unresolved_blue').length+' 处；白线内边界'+(v.lane_valid?'已识别':'未确认')+'；红色地面 '+Math.round((v.road_context?.red_ground_fraction??0)*100)+'%';
 }).join(' / '):'尚无新鲜识别结果';
 const names={'geometry.rear_axle_to_front_m':'后轴到车头距离','geometry.rear_overhang_m':'后悬长度','geometry.clearance_m':'车身与障碍余量','geometry.measured':'完整车辆尺寸',
  'ground.verified_mapping':'已有地面标定的当前姿态／白线覆盖复核','ground.max_error_m':'已有地面标定的当前姿态／白线覆盖复核','motion.minimum_turn_radius_m':'实测转弯半径','motion.maximum_tracking_error_m':'允许路径偏差','motion.braking_distance_m':'实测制动距离','motion.verified':'转向和制动实测确认','motion.pose_feedback_verified':'光流位移实测确认',
  'driving.fixed_camera_confirmed':'已有地面标定的当前姿态／白线覆盖复核','driving.steering_verified':'转向和制动实测确认','driving.odometry_verified':'光流位移实测确认','driving.steering_radius_1570_cm':'1570 μs 转弯半径','driving.steering_radius_1650_cm':'1650 μs 转弯半径','driving.visual_error_bound_m':'光流误差上限','driving.visual_verified_distance_m':'光流核对行程'};
 el('cone-readiness').textContent=c.readiness?.ready?'软件接入已就绪；场地测试仍需操作者开始。':'待补齐：'+[...new Set((c.readiness?.missing||[]).map(k=>names[k]||k))].join('、');
 if(!fresh){el('cone-preview').hidden=true;el('cone-placeholder').hidden=false;el('cone-placeholder').textContent=coneActive?'等待新鲜摄像头画面':'开始识别后显示真实画面';}
 if(coneDriveActive||coneShortActive){
  lastStatus=s;held.clear();heartbeatDue=false;needsRelease=true;allowed=false;turnAvailable=false;motorAvailable=false;reverseAvailable=false;gamepadControl?.requireNeutral();
  for(const id of ['drive-enable','drive-reset','drive-next','drive-speed','test-mode','gamepad-arm','drive-focus'])if(el(id))el(id).disabled=true;
  document.querySelectorAll('[data-drive],[data-speed]').forEach(b=>b.disabled=true);
  el('drive-title').textContent=coneShortActive?'固定档转向／刹车短测':'独立锥桶避障';el('drive-mode').textContent=coneShortActive?q.reason:a.reason;el('drive-action').textContent=coneShortActive?(qo.phase||'准备'):(a.intent?.action||'准备');
 }
 return coneDriveActive||coneShortActive;
}
for(const id of coneInputs)el(id).addEventListener('input',()=>coneDirty=true);
document.querySelectorAll('[data-cone-geometry]').forEach(input=>input.addEventListener('input',()=>coneDirty=true));
document.querySelectorAll('[data-cone-drive],[data-cone-motion]').forEach(input=>input.addEventListener('input',()=>coneDirty=true));
for(const id of ['cone-steering-verified','cone-odometry-verified'])el(id).addEventListener('change',()=>coneDirty=true);
async function coneAction(action,body={}){
 if(coneBusy)return;coneError='';coneBusy=true;if(lastStatus)render(lastStatus);
 try{const s=await send(action,body);if(action==='cone_settings')coneDirty=false;render(s);}
 catch(e){coneError=e.message;feedback(e.message,'error');}
 finally{coneBusy=false;if(lastStatus)render(lastStatus);}
}
el('cone-surface').addEventListener('change',()=>coneDirty=true);
el('cone-save-surface').addEventListener('click',()=>coneAction('cone_settings',{scene_surface:el('cone-surface').value}));
el('cone-observe').addEventListener('click',()=>coneAction('cone_observe'));
el('cone-stop').addEventListener('click',()=>coneAction('cone_stop'));
function saveConeSettings(){
 for(const id of coneInputs){if(!el(id).checkValidity()){el(id).reportValidity();return;}}
 const geometry={};
 const driving={steering_verified:el('cone-steering-verified').checked,odometry_verified:el('cone-odometry-verified').checked},motion={};
 for(const input of document.querySelectorAll('[data-cone-drive],[data-cone-motion]')){
  if(!input.checkValidity()){input.reportValidity();return;}
  (input.dataset.coneDrive?driving:motion)[input.dataset.coneDrive||input.dataset.coneMotion]=input.value===''?null:Number(input.value);
 }
 for(const input of document.querySelectorAll('[data-cone-geometry]')){
  if(!input.checkValidity()){input.reportValidity();return;}geometry[input.dataset.coneGeometry.replace(/_m$/,'')]=input.value===''?null:Number(input.value);
 }
 coneAction('cone_settings',{blue_hsv_lower:[Number(el('cone-h-low').value),Number(el('cone-s-low').value),Number(el('cone-v-low').value)],
  blue_hsv_upper:[Number(el('cone-h-high').value),255,255],confirm_frames:Number(el('cone-confirm').value),red_ground_percent:Number(el('cone-red-percent').value),geometry_cm:geometry,driving:driving,motion_cm:motion});
}
el('cone-save').addEventListener('click',saveConeSettings);
el('cone-save-dimensions').addEventListener('click',saveConeSettings);
el('cone-save-driving').addEventListener('click',saveConeSettings);
el('cone-save-calibration').addEventListener('click',()=>{
 try{coneAction('cone_calibration',{calibration:JSON.parse(el('cone-calibration-json').value)});}catch(e){coneError='标定 JSON 格式错误：'+e.message;if(lastStatus)render(lastStatus);}
});
el('cone-prepare').addEventListener('click',()=>{
 if(coneDirty){coneError='参数尚未保存，请停止识别并保存参数后再准备';if(lastStatus)render(lastStatus);return;}
 coneSequence=0;coneAction('cone_prepare',{esc_off:true,fb_mode_confirmed:true});
});
function coneRunSend(action,body={}){
 const token=coneToken;
 const run=()=>{if(!coneDriveActive||stale||token!==coneToken)throw new Error('本轮已结束');return send(action,{run_token:token,trial_sequence:++coneSequence,...body});};
 const p=coneRunQueue.then(run,run);coneRunQueue=p.catch(()=>{});return p;
}
el('cone-drive-start').addEventListener('click',async()=>{
 if(coneBusy)return;coneBusy=true;coneError='';if(lastStatus)render(lastStatus);
 try{render(await coneRunSend('cone_start',{fb_mode_confirmed:true,esc_on_static:true,field_ready:true}));}
 catch(e){coneError=e.message;}finally{coneBusy=false;if(lastStatus)render(lastStatus);}
});
el('cone-drive-stop').addEventListener('click',()=>coneAction('cone_cancel'));
el('cone-short-prepare').addEventListener('click',()=>{
 coneShortSequence=0;coneAction('cone_short_prepare',{esc_off:true,fb_mode_confirmed:true});
});
el('cone-short-stop').addEventListener('click',()=>stop('stop',false,'stop_button'));
function coneShortSend(action,body={}){
 const token=coneShortToken;
 const run=()=>{if(!coneShortActive||stale||token!==coneShortToken)throw new Error('短测会话已结束');return send(action,{run_token:token,trial_sequence:++coneShortSequence,...body});};
 const p=coneShortQueue.then(run,run);coneShortQueue=p.catch(()=>{});return p;
}
async function startConeShort(mode){
 if(coneShortStartBusy)return;
 for(const id of ['cone-short-forward','cone-short-duration'])if(!el(id).checkValidity()){el(id).reportValidity();return;}
 const round=coneShortRound,forward=Number(el('cone-short-forward').value),duration=Number(el('cone-short-duration').value);
 coneShortStartBusy=true;coneError='';if(lastStatus)render(lastStatus);
 try{render(await coneShortSend('cone_short_start',{mode,forward_us:forward,duration_s:duration,expected_round:round,fb_mode_confirmed:true,esc_on_static:true,field_ready:true}));}
 catch(e){coneError=e.message;}finally{coneShortStartBusy=false;if(lastStatus)render(lastStatus);}
}
el('cone-short-1570').addEventListener('click',()=>startConeShort('turn_1570'));
el('cone-short-1650').addEventListener('click',()=>startConeShort('turn_1650'));
el('cone-short-brake').addEventListener('click',()=>startConeShort('brake'));
setInterval(async()=>{
 if(!coneShortActive||!coneShortOwned||stale||document.hidden||coneShortPulseBusy)return;
 coneShortPulseBusy=true;
 try{render(await coneShortSend('cone_short_keepalive'));}
 catch(e){if(coneShortActive){coneError=e.message;stop('stop',false,'connection_recovery');}}
 finally{coneShortPulseBusy=false;}
},100);
setInterval(async()=>{
 if(!coneDriveActive||!coneDriveOwned||stale||document.hidden||conePulseBusy)return;
 conePulseBusy=true;
 try{render(await coneRunSend('cone_keepalive'));}catch(e){if(coneDriveActive){coneError=e.message;stop('stop',false,'connection_recovery');}}
 finally{conePulseBusy=false;}
},100);
setInterval(async()=>{
 if(!coneActive||stale||document.hidden||coneImageBusy)return;
 coneImageBusy=true;const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),1500);
 try{
  const r=await fetch('/api/cone/frame.jpg',{cache:'no-store',signal:controller.signal});if(!r.ok)throw new Error('no fresh frame');
  const blob=await r.blob();if(!coneActive)return;
  const url=URL.createObjectURL(blob),old=coneImageURL;coneImageURL=url;
  el('cone-preview').src=url;el('cone-preview').hidden=false;el('cone-placeholder').hidden=true;if(old)URL.revokeObjectURL(old);
 }catch(e){el('cone-preview').hidden=true;el('cone-placeholder').hidden=false;}
 finally{clearTimeout(timer);coneImageBusy=false;}
},400);
})();
