"""Operator-requested manual endpoints; independent of autonomous calibration.

The 2026-10-12 request retains the 1610-us center and asks for larger,
symmetric manual deflection. These pulse targets are not measured wheel angles.
"""

REQUESTED_CENTER_US = 1610
REQUESTED_SPAN_US = 180
REQUESTED_MIN_US = REQUESTED_CENTER_US - REQUESTED_SPAN_US
REQUESTED_MAX_US = REQUESTED_CENTER_US + REQUESTED_SPAN_US


def manual_endpoints(center_us, span_us=0):
    if type(span_us) is not int or span_us not in (0, REQUESTED_SPAN_US):
        raise ValueError('unsupported manual steering span')
    if span_us:
        if type(center_us) is not int or center_us != REQUESTED_CENTER_US:
            raise ValueError('symmetric manual endpoints require the requested 1610-us center')
        return center_us + span_us, center_us - span_us
    return 1750, 1550
