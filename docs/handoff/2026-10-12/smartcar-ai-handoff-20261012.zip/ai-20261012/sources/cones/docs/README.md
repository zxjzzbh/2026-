# 项目文档

| 文档 | 用途 |
|---|---|
| [当前进度](current-status.md) | 2026-10-08 当前硬件、功能与未验收项 |
| [源码审查](reviews/2026-10-08-source-review.md) | 技术栈、缺口、离线复现与改进顺序 |
| [团队分工](team.md) | 谁维护哪个模块、如何联调 |
| [系统架构](architecture.md) | 模块职责和数据流 |
| [视觉路线](vision-roadmap.md) | 从离线回放到实车视觉的开发次序 |
| [规则记录](rules/README.md) | 规则版本、任务与待确认条款 |
| [参考资料](references/README.md) | 来源、可借鉴内容、使用边界 |
| [测试记录](testing/README.md) | 环境、操作、实测结果与限制 |
| [技术报告](reports/README.md) | 自己完成的案例、报告草稿和证据 |
| [模块说明模板](templates/module.md) | 新模块的运行与接口说明 |
| [实验记录模板](templates/experiment.md) | 算法比较与实车实验记录 |

按内容归档，文件名清楚表达主题；更新同一份文档，不堆积“最终版”副本。规则和资料原件是否重新发布需单独确认，本仓库当前仅提供摘要与索引。
