"""Explicit session-only open-field corridor. Never fabricates white lines.

The starting rear axle is the origin; the configured race width is retained.
Only the calibrated ground polygon supplies forward visibility. The operator
confirms clear space; this is not general obstacle recognition or race proof.
"""
import math

import cv2
import numpy as np

from .brake_parking import numeric
from .autonomy_profile import GroundProjection


TRACK = 'white_line_track'
OPEN_FIELD = 'open_field'


def test_mode(settings):
    mode = settings.get('_test_mode', TRACK)
    if mode not in (TRACK, OPEN_FIELD):
        raise ValueError('未知锥桶测试场地模式')
    if mode == OPEN_FIELD and settings.get('_open_field_confirmed') is not True:
        raise ValueError('无白线模式需确认测试走廊及停车余地空旷')
    return mode


def open_field_corridor(settings, pose, travel_m):
    """Return moving local coordinates of a corridor fixed at preparation."""
    if test_mode(settings) != OPEN_FIELD:
        raise ValueError('未选择无白线空地测试')
    width = settings['geometry']['lane_width_m']
    if (pose.get('valid') is not True
            or any(not numeric(pose.get(k)) for k in ('x_m', 'y_m', 'yaw_rad'))
            or not numeric(width) or width <= 0 or not numeric(travel_m) or travel_m < 0):
        raise ValueError('无白线测试的位移或走廊宽度无效')
    heading = -pose['yaw_rad']
    if abs(heading) > .4:
        raise ValueError('车辆朝向偏离固定测试走廊')
    bounds = [-width/2-pose['x_m'], width/2-pose['x_m']]
    projection = GroundProjection(settings['ground'])
    # A homography crossing the horizon must not become a made-up long range.
    homogeneous = np.c_[projection.poly, np.ones(len(projection.poly))] @ projection.h.T
    if np.any(np.abs(homogeneous[:, 2]) < 1e-9) or np.any(homogeneous[:, 2]*homogeneous[0, 2] <= 0):
        raise ValueError('地面标定区域穿过投影边界')
    polygon = homogeneous[:, :2] / homogeneous[:, 2:]
    co, si = math.cos(heading), math.sin(heading)
    # Use normal-to-corridor x and local forward y. In this affine frame,
    # convexity makes the common interval at both edges a covered rectangle.
    polygon[:, 0] = co*polygon[:, 0]-si*polygon[:, 1]
    if not np.isfinite(polygon).all() or not cv2.isContourConvex(polygon.astype(np.float32)):
        raise ValueError('无可用的地面标定区域')
    intervals = []
    for edge in bounds:
        intersections = []
        for a, b in zip(polygon, np.roll(polygon, -1, axis=0)):
            if abs(a[0]-b[0]) < 1e-9:
                if abs(a[0]-edge) < 1e-9: intersections.extend([a[1], b[1]])
            elif min(a[0], b[0])-1e-9 <= edge <= max(a[0], b[0])+1e-9:
                intersections.append(a[1]+(b[1]-a[1])*(edge-a[0])/(b[0]-a[0]))
        if not intersections:
            raise ValueError('地面标定未覆盖测试走廊两侧，请复核摄像头视野')
        intervals.append((min(intersections), max(intersections)))
    near = max(0., max(p[0] for p in intervals))
    far = min(p[1] for p in intervals)
    # Stay within the already measured odometry travel, never infer distance
    # from throttle. Existing time, speed and actuator limits remain in force.
    remaining = settings['driving']['visual_verified_distance_m']-travel_m
    far = min(far, remaining)
    if far-near < .3:
        raise ValueError('无白线测试的可信前方覆盖或已核对行程不足')
    return bounds, heading, float(far)
